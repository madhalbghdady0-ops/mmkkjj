import Replicate from "replicate";

export type ImageConfig = {
  apiKey: string;
  model: string;
};

export const imageSettings: Omit<ImageConfig, "apiKey"> = {
  model: "stability-ai/stable-diffusion-3",
};

export function generateImage(config: ImageConfig, prompt: string, stream = true, signal?: AbortSignal) {
  const replicate = new Replicate({
    auth: config.apiKey,
  });

  return replicate.run(config.model, {
    input: {
      prompt,
      num_outputs: 1,
      aspect_ratio: "1:1",
      output_format: "png",
    },
  });
}
