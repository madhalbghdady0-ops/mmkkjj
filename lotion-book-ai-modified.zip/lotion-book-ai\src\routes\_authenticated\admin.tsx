import { createFileRoute, redirect } from "@tanstack/react-router";
import { queryOptions, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { accountQuery, announcementsQuery } from "@/lib/account";

const statsQuery = queryOptions({
  queryKey: ["admin-stats"],
  queryFn: async () => {
    const { data, error } = await supabase.rpc("admin_stats");
    if (error) throw error;
    return data as { users: number; new_week: number; with_goal: number; admins: number };
  },
});

const ownerNotesQuery = queryOptions({
  queryKey: ["owner-notes"],
  queryFn: async () => {
    const { data } = await supabase.from("owner_settings").select("instructions").eq("id", 1).maybeSingle();
    return data?.instructions ?? "";
  },
});

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "لوحة الأدمن — Lotion Book AI" },
      { name: "description", content: "إحصائيات وفعاليات منصة Lotion Book AI." },
      { property: "og:title", content: "لوحة الأدمن — Lotion Book AI" },
      { property: "og:description", content: "إحصائيات وفعاليات المنصة." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  beforeLoad: async ({ context }) => {
    const acc = await context.queryClient.ensureQueryData(accountQuery);
    if (!acc.isAdmin) throw redirect({ to: "/chat" });
  },
  loader: ({ context }) =>
    Promise.all([context.queryClient.ensureQueryData(ownerNotesQuery), context.queryClient.ensureQueryData(statsQuery), context.queryClient.ensureQueryData(announcementsQuery)]),
  component: AdminPage,
});

function AdminPage() {
  const { data: stats } = useSuspenseQuery(statsQuery);
  const { data: news } = useSuspenseQuery(announcementsQuery);
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [days, setDays] = useState(7);
  const { data: notesRow } = useSuspenseQuery(ownerNotesQuery);
  const [notes, setNotes] = useState(notesRow);

  async function saveNotes() {
    const { error } = await supabase.from("owner_settings").upsert({ id: 1, instructions: notes.slice(0, 4000), updated_at: new Date().toISOString() });
    if (error) {
      toast.error("ماتحفظش.");
      return;
    }
    toast.success("اتحفظت ✅ البوت هيلتزم بيها مع كل المستخدمين.");
    qc.invalidateQueries({ queryKey: ["owner-notes"] });
  }

  async function publish() {
    if (!title.trim()) {
      toast.error("اكتب عنوان الفعالية.");
      return;
    }
    const expires = new Date(Date.now() + Math.min(60, Math.max(1, days)) * 86400000).toISOString();
    const { error } = await supabase.from("announcements").insert({ title: title.trim().slice(0, 80), body: body.trim().slice(0, 400), expires_at: expires });
    if (error) {
      toast.error("مانشرتش. جرّب تاني.");
      return;
    }
    toast.success("اتنشرت 📣 كل المستخدمين هيشوفوها فوق الشات.");
    setTitle("");
    setBody("");
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }

  async function remove(id: string) {
    await supabase.from("announcements").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }

  const cards = [
    { label: "كل المستخدمين", value: stats.users },
    { label: "جداد الأسبوع ده", value: stats.new_week },
    { label: "كتبوا هدفهم", value: stats.with_goal },
    { label: "الأدمنز", value: stats.admins },
  ];

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-4xl space-y-8 px-4 py-8">
        <div>
          <h1 className="font-display text-3xl">👑 لوحة الأدمن</h1>
          <p className="mt-1 text-sm text-muted-foreground">المحادثات مبتتخزنش، فمحدش (ولا إنت) يقدر يقرا كلام حد. هنا إحصائيات وفعاليات بس.</p>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {cards.map((c) => (
            <div key={c.label} className="glass rounded-2xl p-5">
              <div className="font-display text-4xl text-primary">{c.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{c.label}</div>
            </div>
          ))}
        </div>

        <section className="glass space-y-3 rounded-2xl p-6">
          <h2 className="text-lg font-bold">👑 أوامر المالك الثابتة للبوت</h2>
          <p className="text-sm text-muted-foreground">اكتب أي أسلوب أو معلومات ثابتة عايز البوت يلتزم بيها مع كل المستخدمين. محدش غيرك يقدر يشوفها أو يغيرها. وتقدر كمان تعدّل أي رد في الشات بزرار «تعديل (المالك)».</p>
          <Textarea rows={5} maxLength={4000} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مثال: ابدأ كل ملزمة بآية أو حكمة. اذكر إن المنصة فيها مسابقة كل جمعة." />
          <Button onClick={saveNotes} className="font-bold">حفظ الأوامر</Button>
        </section>

        <section className="glass space-y-4 rounded-2xl p-6">
          <h2 className="text-lg font-bold">📣 انشر فعالية</h2>
          <div className="space-y-2">
            <Label htmlFor="t">العنوان</Label>
            <Input id="t" maxLength={80} value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="b">التفاصيل</Label>
            <Textarea id="b" maxLength={400} value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
          <div className="flex items-end gap-3">
            <div className="space-y-2">
              <Label htmlFor="d">تفضل ظاهرة كام يوم؟</Label>
              <Input id="d" type="number" min={1} max={60} className="w-28" value={days} onChange={(e) => setDays(Number(e.target.value))} />
            </div>
            <Button onClick={publish} className="font-bold">انشر</Button>
          </div>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold">الفعاليات الشغالة</h2>
          {news.length === 0 && <p className="text-sm text-muted-foreground">مفيش فعاليات دلوقتي.</p>}
          {news.map((a) => (
            <div key={a.id} className="glass flex items-center justify-between rounded-xl p-4">
              <div>
                <b>{a.title}</b>
                <div className="text-xs text-muted-foreground">لحد {new Date(a.expires_at).toLocaleDateString("ar-EG")}</div>
              </div>
              <Button variant="ghost" size="icon" aria-label="مسح" onClick={() => remove(a.id)}>
                <Trash2 />
              </Button>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
