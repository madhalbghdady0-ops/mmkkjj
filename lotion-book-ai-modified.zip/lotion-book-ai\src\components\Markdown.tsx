import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

/** Safe markdown renderer for AI answers (no raw HTML). */
export function Markdown({ children }: { children: string }) {
  return (
    <div className="prose-lotion">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{children}</ReactMarkdown>
    </div>
  );
}
