import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpenText, Target, MessageCircleHeart, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lotion Book AI — مساعدك في المذاكرة وتطوير الذات" },
      { name: "description", content: "اسأل في أي مادة، اعمل جدول مذاكرة، وافتكر هدفك كل يوم. عافر حلمك يستاهل." },
      { property: "og:title", content: "Lotion Book AI — مساعدك في المذاكرة" },
      { property: "og:description", content: "مساعد ذكي بالعربي للمذاكرة وتطوير الذات. عافر حلمك يستاهل." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: MessageCircleHeart, title: "شات بالعربي", body: "اسأل في أي درس واتشرحلك ببساطة وبأمثلة." },
  { icon: Target, title: "بيفتكر هدفك", body: "اكتب حلمك مرة، وهو يفكّرك بيه وقت ما تتعب." },
  { icon: ShieldCheck, title: "خصوصيتك محفوظة", body: "محادثاتك مبتتخزنش، وبياناتك بتبان ليك إنت بس." },
];

function Landing() {
  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col px-5">
      <header className="flex items-center justify-between py-6">
        <div className="flex items-center gap-2 font-display text-xl">
          <BookOpenText className="size-6 text-primary" /> Lotion Book AI
        </div>
        <Button asChild variant="outline">
          <Link to="/auth">دخول</Link>
        </Button>
      </header>

      <section className="flex flex-1 flex-col items-center justify-center py-16 text-center animate-rise">
        <p className="mb-4 rounded-full border px-4 py-1 text-sm text-muted-foreground">
          مساعدك في المذاكرة وتطوير نفسك
        </p>
        <h1 className="font-display text-5xl leading-tight md:text-7xl">
          عافر، <span className="text-primary">حلمك يستاهل</span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-muted-foreground">
          ذاكر مع مساعد ذكي بيتكلم بلغتك، بيشرحلك ويعملك جدول، ويفكّرك بهدفك كل يوم.
        </p>
        <div className="mt-10 flex gap-3">
          <Button asChild size="lg" className="font-bold">
            <Link to="/auth" search={{ mode: "signup" }}>ابدأ مجانًا</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/auth" search={{ mode: "login" }}>عندي حساب</Link>
          </Button>
        </div>
      </section>

      <section className="grid gap-4 pb-16 md:grid-cols-3">
        {features.map((f) => (
          <div key={f.title} className="glass rounded-2xl p-6">
            <f.icon className="mb-3 size-6 text-primary" />
            <h3 className="text-lg font-bold">{f.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.body}</p>
          </div>
        ))}
      </section>
      <footer className="pb-8 text-center text-xs text-muted-foreground">eng.Moaz.Elbghdady</footer>
    </main>
  );
}
