# Lotion Book AI

مساعد ذكي للمذاكرة وتطوير الذات - مبني باستخدام TanStack Start.

## التغييرات المفتوحة المصدر

تم استبدال جميع الخدمات المدفوعة بخدمات مفتوحة المصدر أو مجانية:

### ✅ تم تغيير:
- **AI Chat**: من Lovable AI Gateway → **Groq** (مجاني وسريع باستخدام Llama 3.3)
- **توليد الصور**: من Lovable AI Gateway → **Replicate API** (مجاني للمشاريع الصغيرة)
- **تسجيل الدخول بـ Google**: من Lovable Cloud Auth → **Supabase Auth** (مدمج ومجاني)

### 🗑️ تم إزالة:
- `@ai-sdk/openai` (OpenAI paid)
- `@lovable.dev/cloud-auth-js` (Lovable paid auth)
- مكتبات Lovable AI Gateway

## إعداد المشروع

### 1. الحصول على المفاتيح

**Groq API Key** (للمحادثات الذكية):
- افتح https://console.groq.com/
- سجل دخول وإنشاء API Key مجانية
- انسخ المفتاح

**Replicate API Key** (لتوليد الصور):
- افتح https://replicate.com/account/api-tokens
- سجل دخول وإنشاء API Token
- انسخ المفتاح

**Supabase Google OAuth** (لتسجيل الدخول بـ Google):
- افتح Supabase Dashboard الخاص بمشروعك
- اذهب إلى Authentication → Providers → Google
- قم بتفعيل Google OAuth وأضف معلومات التطبيق من Google Cloud Console

### 2. تحديث ملف .env

أضف المفاتيح إلى ملف `.env`:

```env
GROQ_API_KEY="your_groq_api_key_here"
REPLICATE_API_KEY="your_replicate_api_key_here"
```

### 3. التثبيت والتشغيل

```sh
npm install
npm run dev
```

## التطوير

تم بناء المشروع باستخدام:
- TanStack Start
- TypeScript
- React
- Tailwind CSS
- Supabase (للمصادقة وقاعدة البيانات)
- Groq (للمحادثات الذكية)
- Replicate (لتوليد الصور)

## الميزات

- محادثات ذكية مع AI
- رفع الملفات (PDF، صور، Word)
- توليد صور وإنفوجرافيك تعليمي
- أنظمة ذكية للدراسة (تلخيص، استخراج، تخطيط، معلم تفاعلي)
- وضع للطلاب والمعلمين
- تسجيل دخول بالبريد أو Google
