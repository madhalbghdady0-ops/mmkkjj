import { createFileRoute } from "@tanstack/react-router";
import { generateImage, imageSettings } from "@/lib/image-gateway.server";
import { jsonError, verifyUser } from "@/lib/verify-user.server";

export const Route = createFileRoute("/api/generate-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const auth = await verifyUser(request);
        if (!auth) return jsonError(401, "سجّل دخول الأول.");
        const apiKey = process.env["REPLICATE_API_KEY"];
        if (!apiKey) return jsonError(500, "توليد الصور مش متضبط على السيرفر.");
        const body = (await request.json().catch(() => ({}))) as { prompt?: string; stream?: boolean };
        const prompt = String(body.prompt ?? "").trim().slice(0, 4000);
        if (!prompt) return jsonError(400, "اكتب وصف الصورة الأول.");
        try {
          const result = await generateImage({ ...imageSettings, apiKey }, prompt, body.stream !== false);
          // Replicate returns an array of image URLs
          const imageUrl = Array.isArray(result) ? result[0] : result;
          return new Response(JSON.stringify({ url: imageUrl }), {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              "Cache-Control": "no-cache",
            },
          });
        } catch (error) {
          console.error("Image generation error:", error);
          return jsonError(500, "فشل توليد الصورة. جرّب تاني.");
        }
      },
    },
  },
});
