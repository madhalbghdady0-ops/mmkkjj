import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { accountQuery } from "@/lib/account";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "ملفي — Lotion Book AI" },
      { name: "description", content: "اكتب هدفك وحلمك عشان Lotion Book AI يفكّرك بيهم." },
      { property: "og:title", content: "ملفي — Lotion Book AI" },
      { property: "og:description", content: "هدفك وحلمك في مكان واحد." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(accountQuery),
  component: ProfilePage,
});

const FIELDS = [
  { key: "display_name", label: "اسمك", max: 40 },
  { key: "grade", label: "الصف / المرحلة", max: 60 },
  { key: "goal", label: "هدفك الدراسي", max: 200 },
  { key: "dream", label: "حلمك وطموحك", max: 200 },
  { key: "struggles", label: "إيه اللي بيتعبك في المذاكرة؟", max: 240 },
] as const;
type Key = (typeof FIELDS)[number]["key"];

function ProfilePage() {
  const { data } = useSuspenseQuery(accountQuery);
  const qc = useQueryClient();
  const [form, setForm] = useState<Record<Key, string>>(() => ({
    display_name: data.profile?.display_name ?? "",
    grade: data.profile?.grade ?? "",
    goal: data.profile?.goal ?? "",
    dream: data.profile?.dream ?? "",
    struggles: data.profile?.struggles ?? "",
  }));
  const [kind, setKind] = useState(data.profile?.account_type === "teacher" ? "teacher" : "student");
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    const clean = Object.fromEntries(FIELDS.map((f) => [f.key, form[f.key].trim().slice(0, f.max)]));
    const { error } = await supabase.from("profiles").update({ ...clean, account_type: kind, updated_at: new Date().toISOString() }).eq("id", data.user.id);
    setSaving(false);
    if (error) {
      toast.error("ماتحفظش. جرّب تاني.");
      return;
    }
    toast.success("اتحفظ ✅ من دلوقتي هفكّرك بهدفك.");
    qc.invalidateQueries({ queryKey: ["account"] });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-xl px-4 py-8">
        <h1 className="font-display text-3xl">ملفي 🎯</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {data.user.email}
          {data.isAdmin && <span className="ms-2 rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">أدمن</span>}
        </p>
        <div className="glass mt-6 space-y-4 rounded-2xl p-6">
          <div className="space-y-2">
            <Label>أنا</Label>
            <div className="grid grid-cols-2 gap-2">
              {[["student", "🎓 طالب"], ["teacher", "👩‍🏫 معلم"]].map(([v, l]) => (
                <Button key={v} type="button" variant={kind === v ? "default" : "outline"} onClick={() => setKind(v!)}>
                  {l}
                </Button>
              ))}
            </div>
          </div>
          {FIELDS.map((f) => (
            <div key={f.key} className="space-y-2">
              <Label htmlFor={f.key}>{f.label}</Label>
              <Input id={f.key} maxLength={f.max} value={form[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
            </div>
          ))}
          <Button onClick={save} disabled={saving} className="w-full font-bold">
            {saving ? "بيحفظ..." : "حفظ"}
          </Button>
        </div>
      </main>
    </div>
  );
}
