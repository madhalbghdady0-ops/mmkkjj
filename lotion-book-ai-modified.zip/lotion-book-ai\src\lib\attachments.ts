import type { FileUIPart } from "ai";

export const ACCEPT = "application/pdf,image/*,.txt,.md,.csv,.docx";
const MAX_BYTES = 15 * 1024 * 1024;

export type Prepared = { files: FileUIPart[]; extraText: string };

function readAsDataURL(file: File) {
  return new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

/**
 * PDFs and images go to the model as files (it reads them directly, including scanned pages).
 * Text and Word files are extracted to text in the browser.
 */
export async function prepareAttachments(list: File[]): Promise<Prepared> {
  const files: FileUIPart[] = [];
  let extraText = "";
  for (const f of list) {
    if (f.size > MAX_BYTES) throw new Error(`الملف «${f.name}» أكبر من 15 ميجا.`);
    const name = f.name.toLowerCase();
    if (f.type === "application/pdf" || f.type.startsWith("image/")) {
      files.push({ type: "file", mediaType: f.type, filename: f.name, url: await readAsDataURL(f) });
    } else if (name.endsWith(".docx")) {
      const mammoth = await import("mammoth/mammoth.browser");
      const { value } = await mammoth.extractRawText({ arrayBuffer: await f.arrayBuffer() });
      extraText += `\n\n--- محتوى ملف ${f.name} ---\n${value.slice(0, 18000)}`;
    } else if (/\.(txt|md|csv)$/.test(name) || f.type.startsWith("text/")) {
      extraText += `\n\n--- محتوى ملف ${f.name} ---\n${(await f.text()).slice(0, 18000)}`;
    } else {
      throw new Error(`نوع الملف «${f.name}» مش مدعوم. استخدم PDF أو صورة أو Word أو نص.`);
    }
  }
  return { files, extraText };
}

export function infographicPrompt(content: string) {
  return `Create a clean, modern educational infographic poster in Arabic (right-to-left layout).
Use a clear large title at the top, 4-6 numbered sections with simple flat icons, soft warm colors (navy, amber, cream), high contrast, readable Arabic typography, no clutter.
Content to visualize:
${content.slice(0, 1500)}`;
}
