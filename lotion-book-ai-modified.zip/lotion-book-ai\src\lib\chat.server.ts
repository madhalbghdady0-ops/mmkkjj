import { createGroq } from "@ai-sdk/groq";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { verifyUser } from "./verify-user.server";
import { buildSystemPrompt, checkInput, MAX_INPUT_CHARS } from "./lotion";
import { LEVEL_INSTRUCTIONS, SYSTEM_INSTRUCTIONS, type Level, type SystemId } from "./systems";

const MODEL = "llama-3.3-70b-versatile";

function json(status: number, error: string) {
  return new Response(JSON.stringify({ error }), { status, headers: { "content-type": "application/json" } });
}

export async function handleChat(request: Request) {
  const auth = await verifyUser(request);
  if (!auth) return json(401, "سجّل دخول الأول أو الجلسة انتهت.");
  const { user, supabase } = auth;

  const apiKey = process.env["GROQ_API_KEY"];
  if (!apiKey) return json(500, "الذكاء الاصطناعي مش متضبط على السيرفر.");

  let body: { messages?: UIMessage[]; system?: string; level?: string; ownerEdit?: string };
  try {
    body = await request.json();
  } catch {
    return json(400, "طلب غلط أو الملف كبير جدًا.");
  }
  // Keep recent history; drop attachments from older turns so they aren't re-sent each time.
  const all = (body.messages ?? []).slice(-12);
  // Assistant-side generated images are UI only; never sent back to the model.
  const messages = all.map((m, i) =>
    m.role === "user" && i >= all.length - 4 ? m : { ...m, parts: m.parts.filter((p) => p.type !== "file") },
  );
  const last = messages[messages.length - 1];
  const lastText = last?.parts?.map((p) => (p.type === "text" ? p.text : "")).join("") ?? "";
  const hasFile = last?.parts?.some((p) => p.type === "file") ?? false;
  if (!lastText.trim() && !hasFile) return json(400, "اكتب رسالتك أو ارفع ملف الأول 🙂");
  if (lastText.length > MAX_INPUT_CHARS) return json(400, `الرسالة طويلة. الحد ${MAX_INPUT_CHARS} حرف.`);

  const [{ data: profile }, { data: roles }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
    supabase.from("user_roles").select("role").eq("user_id", user.id),
  ]);
  const isAdmin = (roles ?? []).some((r) => r.role === "admin");

  const blocked = checkInput(lastText);
  const { data: ownerNotes } = await supabase.rpc("get_owner_instructions");
  let system = buildSystemPrompt(profile, isAdmin, blocked, typeof ownerNotes === "string" ? ownerNotes : "");
  const sys = body.system as SystemId | undefined;
  const level: Level = body.level === "low" || body.level === "high" ? body.level : "medium";
  if (sys && sys in SYSTEM_INSTRUCTIONS) system += "\n\n# " + SYSTEM_INSTRUCTIONS[sys];
  system += "\n" + LEVEL_INSTRUCTIONS[level];
  // Owner-only: rewrite a previous answer on command. Verified from the database role, never from chat text.
  if (body.ownerEdit && isAdmin) {
    system += `\n\n# أمر من المالك (موثّق من حسابه): عدّل الرد ده حسب طلبه في آخر رسالة، وارجع الرد كامل بعد التعديل من غير مقدمات:\n"""\n${String(body.ownerEdit).slice(0, 12000)}\n"""`;
  }

  const provider = createGroq({
    apiKey,
  });

  const result = streamText({
    model: provider(MODEL),
    instructions: system,
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
  });

  return result.toUIMessageStreamResponse({
    onError: (e: unknown) => {
      console.error(e);
      const status = (e as { statusCode?: number })?.statusCode;
      if (status === 402) return "رصيد الذكاء الاصطناعي خلص. صاحب المنصة لازم يزوّد الرصيد.";
      if (status === 429) return "ضغط كبير دلوقتي. استنى دقيقة وجرّب تاني.";
      if (status === 400) return "الملف ده مش مدعوم أو كبير جدًا. جرّب PDF أو صورة أصغر.";
      return "حصلت مشكلة مؤقتة. جرّب تبعت رسالتك تاني بعد شوية 🙏";
    },
  });
}
