import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowUp, Eraser, Square, BookOpenText, Megaphone, Paperclip, X, FileText, Sparkles as Layers,
  FileDown, ImageIcon, Copy, PencilLine, ChevronLeft, Download, Loader2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppHeader } from "@/components/AppHeader";
import { Markdown } from "@/components/Markdown";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { accountQuery, announcementsQuery } from "@/lib/account";
import { ACCEPT, infographicPrompt, prepareAttachments } from "@/lib/attachments";
import { printMarkdownAsPdf } from "@/lib/print-pdf";
import { streamImage } from "@/lib/stream-image";
import { LEVELS, SYSTEMS, type Level, type SystemId } from "@/lib/systems";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({
    meta: [
      { title: "الشات — Lotion Book AI" },
      { name: "description", content: "ذاكر واسأل Lotion Book AI في أي مادة، وارفع ملفاتك." },
      { property: "og:title", content: "الشات — Lotion Book AI" },
      { property: "og:description", content: "ذاكر واسأل Lotion Book AI في أي مادة." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(accountQuery),
      context.queryClient.ensureQueryData(announcementsQuery),
    ]),
  component: ChatPage,
});

const STUDENT_SUGGESTIONS = ["اعملي جدول مذاكرة للأسبوع ده", "عندي دروس متراكمة، ساعدني ألمّها", "اعملي روتين يومي يساعدني أركز", "اعملي ملزمة عن قانون نيوتن"];
const TEACHER_SUGGESTIONS = ["حضّرلي درس عن التمثيل الضوئي", "اعمل امتحان 20 درجة بنموذج إجابة", "ورقة عمل للصف الأول الإعدادي", "خطة توزيع منهج للترم"];

type Img = { url: string; final: boolean; error?: string };

async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const t = data.session?.access_token;
  return t ? { Authorization: `Bearer ${t}` } : {};
}

const textOf = (m: UIMessage) => m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");

function ChatPage() {
  const { data: account } = useSuspenseQuery(accountQuery);
  const { data: news } = useSuspenseQuery(announcementsQuery);
  const [input, setInput] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [system, setSystem] = useState<SystemId | null>(null);
  const [level, setLevel] = useState<Level>("medium");
  const [menuOpen, setMenuOpen] = useState(false);
  const [pickSystem, setPickSystem] = useState<SystemId | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [images, setImages] = useState<Record<string, Img>>({});
  const [preparing, setPreparing] = useState(false);
  const autoVisual = useRef(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const transport = useMemo(() => new DefaultChatTransport({ api: "/api/chat", headers: authHeaders }), []);
  const { messages, sendMessage, status, stop, error, setMessages, clearError } = useChat({
    transport,
    onFinish: ({ message }) => {
      if (autoVisual.current) {
        autoVisual.current = false;
        makeInfographic(message.id, textOf(message));
      }
    },
  });
  const busy = status === "submitted" || status === "streaming" || preparing;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, status, images]);

  const isTeacher = account.profile?.account_type === "teacher";
  const name = account.profile?.display_name || (isTeacher ? "يا أستاذ" : "يا بطل");
  const greeting = account.isAdmin ? `أهلًا يا ${name} 👑 نورت منصتك` : `أهلًا ${name} 👋`;
  const activeSystem = SYSTEMS.find((s) => s.id === system);

  async function makeInfographic(id: string, content: string) {
    if (!content.trim()) return;
    setImages((m) => ({ ...m, [id]: { url: "", final: false } }));
    try {
      await streamImage("/api/generate-image", { prompt: infographicPrompt(content) }, (url, final) =>
        setImages((m) => ({ ...m, [id]: { url, final } })), undefined, await authHeaders());
    } catch (e) {
      setImages((m) => ({ ...m, [id]: { url: "", final: true, error: e instanceof Error ? e.message : "فشل" } }));
    }
  }

  async function send(text: string) {
    const t = text.trim();
    if ((!t && files.length === 0) || busy) return;
    clearError();
    setPreparing(true);
    try {
      const prepared = await prepareAttachments(files);
      const fullText = (t || "اقرا الملف ده واشرحهولي.") + prepared.extraText;
      autoVisual.current = system === "visual";
      sendMessage(
        { text: fullText, files: prepared.files },
        { body: { system: system ?? undefined, level, ownerEdit: editing?.text } },
      );
      setInput("");
      setFiles([]);
      setEditing(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "مقدرتش أقرا الملف.");
    } finally {
      setPreparing(false);
    }
  }

  const suggestions = isTeacher ? TEACHER_SUGGESTIONS : STUDENT_SUGGESTIONS;

  return (
    <div className="flex h-dvh flex-col">
      <AppHeader />
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-5 px-4 py-6">
          {news.map((a) => (
            <div key={a.id} className="flex gap-3 rounded-2xl border border-primary/40 bg-primary/10 p-4 text-sm">
              <Megaphone className="size-5 shrink-0 text-primary" />
              <div>
                <b>{a.title}</b> {a.body && <span className="text-muted-foreground">— {a.body}</span>}
              </div>
            </div>
          ))}

          {messages.length === 0 && (
            <div className="py-8 text-center animate-rise">
              <BookOpenText className="mx-auto size-10 text-primary" />
              <h1 className="mt-4 font-display text-3xl">{greeting}</h1>
              <p className="mt-2 text-muted-foreground">
                {account.profile?.goal ? `فاكر هدفك: «${account.profile.goal}». نشتغل على إيه النهارده؟` : "ارفع ملزمتك 📎 أو اختار نظام ذكي، أو اسألني على طول."}
              </p>
              <div className="mt-8 grid gap-2 sm:grid-cols-2">
                {suggestions.map((s) => (
                  <button key={s} onClick={() => send(s)} className="glass rounded-xl p-3 text-start text-sm hover:border-primary">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => {
            const text = textOf(m);
            const fileParts = m.parts.filter((p) => p.type === "file");
            if (m.role === "user") {
              const shown = text.split("\n\n--- محتوى ملف")[0] ?? text;
              const docs = [...text.matchAll(/--- محتوى ملف (.+?) ---/g)].map((x) => x[1]);
              return (
                <div key={m.id} className="flex flex-col items-start gap-2">
                  {(fileParts.length > 0 || docs.length > 0) && (
                    <div className="flex flex-wrap gap-2">
                      {fileParts.map((p, i) =>
                        p.mediaType.startsWith("image/") ? (
                          <img key={i} src={p.url} alt={p.filename ?? "صورة"} className="h-24 rounded-lg border object-cover" />
                        ) : (
                          <FileChip key={i} name={p.filename ?? "ملف PDF"} />
                        ),
                      )}
                      {docs.map((d) => <FileChip key={d} name={d ?? "ملف"} />)}
                    </div>
                  )}
                  {shown && (
                    <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-ss-sm bg-bubble px-4 py-2.5 text-bubble-foreground">
                      {shown}
                    </div>
                  )}
                </div>
              );
            }
            const img = images[m.id];
            const done = !(status === "streaming" && m.id === messages[messages.length - 1]?.id);
            return (
              <div key={m.id} className="flex gap-3">
                <div className="mt-1 flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary">
                  <BookOpenText className="size-4 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  {text ? <Markdown>{text}</Markdown> : <span className="text-muted-foreground">…</span>}
                  {img && <InfographicView img={img} />}
                  {done && text && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      <ActionBtn icon={FileDown} label="تصدير PDF" onClick={() => printMarkdownAsPdf(text, firstHeading(text))} />
                      <ActionBtn icon={ImageIcon} label="تحويل إلى إنفوجرافيك" disabled={!!img && !img.final} onClick={() => makeInfographic(m.id, text)} />
                      <ActionBtn icon={Copy} label="نسخ" onClick={() => navigator.clipboard.writeText(text).then(() => toast.success("اتنسخ"))} />
                      {account.isAdmin && (
                        <ActionBtn icon={PencilLine} label="تعديل (المالك)" onClick={() => setEditing({ id: m.id, text })} />
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {(status === "submitted" || preparing) && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="size-2 animate-pulse rounded-full bg-primary" /> {preparing ? "بيقرا الملفات..." : "بيفكر..."}
            </div>
          )}
          {error && (
            <div className="rounded-xl border border-destructive/50 bg-destructive/10 p-3 text-sm">{readError(error)}</div>
          )}
          <div ref={endRef} />
        </div>
      </div>

      <div className="border-t bg-background/80 backdrop-blur">
        <div className="mx-auto max-w-3xl space-y-2 px-4 py-3">
          {(activeSystem || editing || files.length > 0) && (
            <div className="flex flex-wrap items-center gap-2 text-xs">
              {editing && (
                <Chip onRemove={() => setEditing(null)} tone="primary">
                  👑 بتعدّل رد: «{editing.text.slice(0, 40)}…» — اكتب التعديل المطلوب
                </Chip>
              )}
              {activeSystem && (
                <Chip onRemove={() => setSystem(null)} tone="primary">
                  {activeSystem.emoji} {activeSystem.title} · {LEVELS.find((l) => l.id === level)?.title}
                </Chip>
              )}
              {files.map((f, i) => (
                <Chip key={i} onRemove={() => setFiles(files.filter((_, j) => j !== i))}>
                  <FileText className="size-3" /> {f.name}
                </Chip>
              ))}
            </div>
          )}
          <form
            className="flex items-end gap-1.5"
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
          >
            <input
              ref={fileRef}
              type="file"
              multiple
              accept={ACCEPT}
              className="hidden"
              onChange={(e) => {
                setFiles([...files, ...Array.from(e.target.files ?? [])].slice(0, 5));
                e.target.value = "";
              }}
            />
            <Button type="button" variant="ghost" size="icon" aria-label="إرفاق ملف" title="إرفاق ملف (PDF، صور، Word، نص)" onClick={() => fileRef.current?.click()} disabled={busy}>
              <Paperclip />
            </Button>

            <Popover open={menuOpen} onOpenChange={(o) => { setMenuOpen(o); if (!o) setPickSystem(null); }}>
              <PopoverTrigger asChild>
                <Button type="button" variant={system ? "secondary" : "ghost"} size="icon" aria-label="الأنظمة الذكية" title="الأنظمة الذكية">
                  <Layers className={system ? "text-primary" : ""} />
                </Button>
              </PopoverTrigger>
              <PopoverContent side="top" align="start" className="glass w-80 rounded-2xl p-2" dir="rtl">
                {!pickSystem ? (
                  <>
                    <div className="px-2 pb-2 pt-1 text-xs font-bold text-muted-foreground">الأنظمة الذكية</div>
                    {SYSTEMS.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => setPickSystem(s.id)}
                        className={`flex w-full items-center gap-3 rounded-xl p-2.5 text-start hover:bg-accent ${system === s.id ? "bg-accent" : ""}`}
                      >
                        <span className="text-xl">{s.emoji}</span>
                        <span className="flex-1">
                          <span className="block text-sm font-bold">{s.title}</span>
                          <span className="block text-xs text-muted-foreground">{s.desc}</span>
                        </span>
                        <ChevronLeft className="size-4 text-muted-foreground" />
                      </button>
                    ))}
                  </>
                ) : (
                  <>
                    <button onClick={() => setPickSystem(null)} className="px-2 pb-2 pt-1 text-xs text-muted-foreground hover:text-foreground">
                      → رجوع · {SYSTEMS.find((s) => s.id === pickSystem)?.title}
                    </button>
                    <div className="px-2 pb-1 text-xs font-bold">اختار مستوى المعالجة</div>
                    {LEVELS.map((l) => (
                      <button
                        key={l.id}
                        onClick={() => {
                          setSystem(pickSystem);
                          setLevel(l.id);
                          setMenuOpen(false);
                          setPickSystem(null);
                        }}
                        className="flex w-full flex-col rounded-xl p-2.5 text-start hover:bg-accent"
                      >
                        <span className="text-sm font-bold">{l.title}</span>
                        <span className="text-xs text-muted-foreground">{l.desc}</span>
                      </button>
                    ))}
                  </>
                )}
              </PopoverContent>
            </Popover>

            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder={editing ? "اكتب التعديل: زوّد الجزء ده، غيّر الصياغة..." : "اكتب سؤالك أو ارفع ملف 📎 (Enter للإرسال)"}
              className="max-h-40 min-h-11 resize-none"
              rows={1}
            />
            {status === "streaming" || status === "submitted" ? (
              <Button type="button" size="icon" variant="secondary" aria-label="إيقاف" onClick={() => stop()}>
                <Square />
              </Button>
            ) : (
              <Button type="submit" size="icon" aria-label="إرسال" disabled={busy || (!input.trim() && files.length === 0)}>
                {preparing ? <Loader2 className="animate-spin" /> : <ArrowUp />}
              </Button>
            )}
            <Button type="button" variant="ghost" size="icon" aria-label="محادثة جديدة" title="محادثة جديدة" onClick={() => { setMessages([]); setImages({}); }} disabled={busy}>
              <Eraser />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

function FileChip({ name }: { name: string }) {
  return (
    <span className="flex items-center gap-1.5 rounded-lg border bg-secondary px-3 py-2 text-xs">
      <FileText className="size-4 text-primary" /> {name}
    </span>
  );
}

function Chip({ children, onRemove, tone }: { children: React.ReactNode; onRemove: () => void; tone?: "primary" }) {
  return (
    <span className={`flex items-center gap-1.5 rounded-full border px-3 py-1 ${tone === "primary" ? "border-primary/50 bg-primary/10" : "bg-secondary"}`}>
      {children}
      <button onClick={onRemove} aria-label="إزالة" className="text-muted-foreground hover:text-foreground">
        <X className="size-3" />
      </button>
    </span>
  );
}

function ActionBtn({ icon: Icon, label, onClick, disabled }: { icon: typeof Copy; label: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground hover:bg-accent hover:text-foreground disabled:opacity-50"
    >
      <Icon className="size-3.5" /> {label}
    </button>
  );
}

function InfographicView({ img }: { img: Img }) {
  if (img.error) return <p className="mt-3 text-sm text-destructive">الصورة ماتعملتش: {img.error}</p>;
  if (!img.url)
    return (
      <div className="mt-3 flex aspect-square max-w-sm items-center justify-center rounded-2xl border bg-secondary text-sm text-muted-foreground">
        <Loader2 className="me-2 size-4 animate-spin" /> بيرسم الإنفوجرافيك...
      </div>
    );
  return (
    <div className="mt-3 max-w-sm">
      <img src={img.url} alt="إنفوجرافيك" className={`rounded-2xl border transition-[filter] duration-500 ${img.final ? "blur-0" : "blur-2xl"}`} />
      {img.final && (
        <a href={img.url} download="lotion-infographic.png" className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">
          <Download className="size-3.5" /> تنزيل الصورة
        </a>
      )}
    </div>
  );
}

function firstHeading(md: string) {
  const h = md.match(/^#{1,3}\s+(.+)$/m);
  return (h?.[1] ?? "ملزمة Lotion Book AI").replace(/[*_`]/g, "").slice(0, 80);
}

function readError(e: Error) {
  try {
    const j = JSON.parse(e.message);
    if (j?.error) return j.error as string;
  } catch {
    /* plain text */
  }
  return e.message || "حصلت مشكلة. جرّب تاني.";
}
