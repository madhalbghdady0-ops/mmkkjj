import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { BookOpenText, Crown, LogOut, MessageCircle, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { accountQuery, signOut } from "@/lib/account";

export function AppHeader() {
  const { data } = useSuspenseQuery(accountQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const link = "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground";
  const active = { className: "bg-accent text-foreground" };

  return (
    <header className="glass sticky top-0 z-10 border-x-0 border-t-0">
      <div className="mx-auto flex max-w-4xl items-center justify-between gap-2 px-4 py-3">
        <Link to="/chat" className="flex items-center gap-2 font-display text-lg">
          <BookOpenText className="size-5 text-primary" />
          <span className="hidden sm:inline">Lotion Book AI</span>
        </Link>
        <nav className="flex items-center gap-1">
          <Link to="/chat" className={link} activeProps={active}>
            <MessageCircle className="size-4" /> الشات
          </Link>
          <Link to="/profile" className={link} activeProps={active}>
            <UserRound className="size-4" /> ملفي
          </Link>
          {data.isAdmin && (
            <Link to="/admin" className={link} activeProps={active}>
              <Crown className="size-4 text-primary" /> لوحة الأدمن
            </Link>
          )}
          <Button
            variant="ghost"
            size="icon"
            aria-label="خروج"
            onClick={async () => {
              await signOut(qc);
              navigate({ to: "/auth", replace: true });
            }}
          >
            <LogOut />
          </Button>
        </nav>
      </div>
    </header>
  );
}
