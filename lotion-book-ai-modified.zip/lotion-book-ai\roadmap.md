# Roadmap

- [x] Login/signup (two buttons) + Google sign-in
- [x] Admin = first account, admin dashboard (stats + announcements)
- [x] AI chat that works without Ollama (Lovable AI)
- [ ] Verify chat end-to-end
- [ ] File upload in chat (PDF, images, text) — AI reads them
- [ ] Generate infographic / illustration images
- [ ] Study tools: daily routine, personal schedule, catch-up plan for backlog
- [ ] Generate notes/booklets as downloadable PDF
- [ ] Student + teacher modes (teacher: lesson plans, exams, worksheets)
- [ ] Deliver full deployable project ZIP (runs on a server like the preview) after each change
- [ ] Explain training on Colab (fine-tuning) vs. what this platform uses
