import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { BookOpenText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const searchSchema = z.object({ mode: z.enum(["login", "signup"]).optional() });

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "دخول أو إنشاء حساب — Lotion Book AI" },
      { name: "description", content: "سجّل دخولك أو اعمل حساب جديد في Lotion Book AI، أو ادخل بحساب Google." },
      { property: "og:title", content: "دخول — Lotion Book AI" },
      { property: "og:description", content: "سجّل دخولك أو اعمل حساب جديد في Lotion Book AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const creds = z.object({
  email: z.string().trim().email("اكتب إيميل صحيح"),
  password: z.string().min(8, "الباسورد لازم 8 حروف على الأقل").max(100),
});

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4-5.5 4-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.4 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12s4.3 9.6 9.6 9.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z" />
    </svg>
  );
}

function AuthPage() {
  const navigate = useNavigate();
  const { mode } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState<null | "login" | "signup" | "google">(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/chat", replace: true });
    });
  }, [navigate]);

  function validate() {
    const r = creds.safeParse({ email, password });
    if (!r.success) {
      toast.error(r.error.issues[0]?.message ?? "بيانات غلط");
      return null;
    }
    return r.data;
  }

  async function login() {
    const v = validate();
    if (!v) return;
    setBusy("login");
    const { error } = await supabase.auth.signInWithPassword(v);
    setBusy(null);
    if (error) {
      toast.error(
        error.message.includes("Email not confirmed")
          ? "لازم تأكد إيميلك الأول. افتح الرسالة اللي وصلتك."
          : "الإيميل أو الباسورد غلط.",
      );
      return;
    }
    navigate({ to: "/chat", replace: true });
  }

  async function signup() {
    const v = validate();
    if (!v) return;
    setBusy("signup");
    const { data, error } = await supabase.auth.signUp({
      ...v,
      options: { emailRedirectTo: window.location.origin + "/chat" },
    });
    setBusy(null);
    if (error) {
      toast.error(error.message.includes("registered") ? "الإيميل ده عليه حساب بالفعل. اعمل دخول." : error.message);
      return;
    }
    if (data.session) navigate({ to: "/chat", replace: true });
    else setSent(true);
  }

  async function google() {
    setBusy("google");
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: window.location.origin + "/chat",
      },
    });
    setBusy(null);
    if (error) {
      toast.error("الدخول بـ Google ماكملش. جرّب تاني.");
      return;
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="glass w-full max-w-md rounded-3xl p-8 animate-rise">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2 font-display text-2xl">
          <BookOpenText className="size-7 text-primary" /> Lotion Book AI
        </Link>

        {sent ? (
          <div className="text-center">
            <h1 className="text-xl font-bold">فاضل خطوة واحدة 📩</h1>
            <p className="mt-3 text-muted-foreground">
              بعتنالك رسالة على <b className="text-foreground">{email}</b>. افتحها ودوس على اللينك عشان حسابك يتفعّل.
            </p>
            <Button variant="outline" className="mt-6" onClick={() => setSent(false)}>
              رجوع
            </Button>
          </div>
        ) : (
          <>
            <h1 className="text-center text-xl font-bold">
              {mode === "signup" ? "اعمل حسابك الجديد" : "أهلًا بيك 👋"}
            </h1>
            <p className="mt-1 text-center text-sm text-muted-foreground">
              اكتب الإيميل والباسورد، وبعدين اختار: دخول ولا حساب جديد.
            </p>

            <form
              className="mt-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                if (mode === "signup") signup();
                else login();
              }}
            >
              <div className="space-y-2">
                <Label htmlFor="email">الإيميل</Label>
                <Input id="email" type="email" dir="ltr" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pw">الباسورد (8 حروف على الأقل)</Label>
                <Input id="pw" type="password" dir="ltr" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3 pt-2">
                <Button type="button" size="lg" className="font-bold" disabled={!!busy} onClick={login}>
                  {busy === "login" ? "..." : "تسجيل دخول"}
                </Button>
                <Button type="button" size="lg" variant="outline" className="font-bold" disabled={!!busy} onClick={signup}>
                  {busy === "signup" ? "..." : "إنشاء حساب"}
                </Button>
              </div>
            </form>

            <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
              <div className="h-px flex-1 bg-border" /> أو <div className="h-px flex-1 bg-border" />
            </div>
            <Button variant="secondary" size="lg" className="w-full" disabled={!!busy} onClick={google}>
              <GoogleIcon /> الدخول بحساب Google
            </Button>
            <p className="mt-6 text-center text-xs text-muted-foreground">🔒 محادثاتك مبتتخزنش، وبياناتك بتبان ليك إنت بس.</p>
          </>
        )}
      </div>
    </main>
  );
}
