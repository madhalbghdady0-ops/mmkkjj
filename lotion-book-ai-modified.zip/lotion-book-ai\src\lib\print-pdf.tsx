import { renderToStaticMarkup } from "react-dom/server";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

// Booklet style for the printable PDF (white paper, RTL, Arabic font).
// Print output is paper, so it uses fixed print colors rather than the dark app theme.
const PRINT_CSS = `
@page { size: A4; margin: 18mm 16mm; }
* { box-sizing: border-box; }
body { font-family: 'Tajawal', sans-serif; direction: rtl; color: #1b2233; line-height: 1.9; font-size: 13pt; }
.cover { border-bottom: 3px solid #e3a33a; padding-bottom: 10px; margin-bottom: 18px; display:flex; justify-content:space-between; align-items:flex-end; }
.cover h1 { font-family: 'Reem Kufi', sans-serif; margin: 0; font-size: 24pt; }
.cover small { color: #6b7280; }
h1,h2,h3 { font-family: 'Reem Kufi', sans-serif; color: #12305a; page-break-after: avoid; }
h2 { border-right: 5px solid #e3a33a; padding-right: 8px; }
table { width: 100%; border-collapse: collapse; margin: 10px 0; page-break-inside: avoid; }
th, td { border: 1px solid #c9d1de; padding: 6px 8px; text-align: right; vertical-align: top; }
th { background: #fdf3e1; }
blockquote { background: #f4f7fb; border-right: 4px solid #12305a; margin: 10px 0; padding: 8px 12px; }
code { background: #f1f1f1; padding: 1px 4px; border-radius: 4px; }
footer { margin-top: 24px; color: #6b7280; font-size: 10pt; text-align: center; }
`;

/** Opens the browser's "Save as PDF" dialog for a markdown document (Arabic-safe). */
export function printMarkdownAsPdf(markdown: string, title = "ملزمة Lotion Book AI") {
  const body = renderToStaticMarkup(<ReactMarkdown remarkPlugins={[remarkGfm]}>{markdown}</ReactMarkdown>);
  const date = new Date().toLocaleDateString("ar-EG");
  const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escapeHtml(title)}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@500;700&family=Tajawal:wght@400;700&display=swap">
<style>${PRINT_CSS}</style></head><body>
<div class="cover"><h1>${escapeHtml(title)}</h1><small>Lotion Book AI · ${date}</small></div>
${body}
<footer>عافر حلمك يستاهل 💪 — Lotion Book AI</footer></body></html>`;

  const frame = document.createElement("iframe");
  frame.style.position = "fixed";
  frame.style.width = "0";
  frame.style.height = "0";
  frame.style.border = "0";
  document.body.appendChild(frame);
  const doc = frame.contentDocument!;
  doc.open();
  doc.write(html);
  doc.close();
  const go = () => {
    frame.contentWindow?.focus();
    frame.contentWindow?.print();
    setTimeout(() => frame.remove(), 60_000);
  };
  // Wait for the Arabic fonts so the PDF doesn't fall back to a system font.
  (doc.fonts?.ready ?? Promise.resolve()).then(() => setTimeout(go, 300));
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
}

export function downloadText(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
