alter table public.profiles add column account_type text not null default 'student';
create or replace function public.validate_account_type() returns trigger language plpgsql set search_path = public as $$
begin
  if new.account_type not in ('student','teacher') then new.account_type := 'student'; end if;
  return new;
end $$;
create trigger profiles_account_type before insert or update on public.profiles
for each row execute function public.validate_account_type();