import { flushSync } from "react-dom";

export async function streamImage(
  endpoint: string,
  input: Record<string, unknown> | FormData,
  onFrame: (dataUrl: string, isFinal: boolean) => void,
  signal?: AbortSignal,
  headers?: HeadersInit,
): Promise<void> {
  signal?.throwIfAborted();
  const requestHeaders = new Headers(headers);
  let body: FormData | string;
  if (input instanceof FormData) {
    const form = new FormData();
    input.forEach((value, name) => form.append(name, value));
    body = form;
    requestHeaders.delete("Content-Type");
  } else {
    body = JSON.stringify(input);
    requestHeaders.set("Content-Type", "application/json");
  }

  const res = await fetch(endpoint, { method: "POST", headers: requestHeaders, body, signal: signal ?? null });
  if (!res.ok) {
    throw new Error(`Image generation failed: ${res.status} ${await res.text().catch(() => "")}`);
  }

  const json = (await res.json()) as { url?: string };
  const imageUrl = json.url;
  if (!imageUrl) throw new Error("Image generation returned no image");

  // Replicate returns a URL, not base64
  flushSync(() => onFrame(imageUrl, true));
}
