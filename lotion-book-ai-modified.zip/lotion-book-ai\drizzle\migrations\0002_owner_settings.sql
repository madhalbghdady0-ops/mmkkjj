create table public.owner_settings (
  id int primary key default 1 check (id = 1),
  instructions text not null default '',
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.owner_settings to authenticated;
grant all on public.owner_settings to service_role;
alter table public.owner_settings enable row level security;
create policy "admin read" on public.owner_settings for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admin insert" on public.owner_settings for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "admin update" on public.owner_settings for update to authenticated using (public.has_role(auth.uid(), 'admin'));
insert into public.owner_settings (id) values (1) on conflict do nothing;

-- Lets the chat server read the owner's standing instructions for any signed-in user.
create or replace function public.get_owner_instructions()
returns text language sql stable security definer set search_path = public
as $$ select coalesce((select instructions from public.owner_settings where id = 1), '') $$;
revoke execute on function public.get_owner_instructions() from anon;
grant execute on function public.get_owner_instructions() to authenticated;